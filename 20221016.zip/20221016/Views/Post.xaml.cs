﻿using Microsoft.Win32;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Walkydoggy.Models;
using Walkydoggy.ViewModels;

namespace Walkydoggy.View
{
    /// <summary>
    /// Post.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Post : Page
    {
        private PostViewModel viewModel = new PostViewModel();

        public Post()
        {
            InitializeComponent();

            this.DataContext = this.viewModel;

            this.InitTime();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            
        }

        /// <summary>
        /// 년월일 데이터 초기화
        /// </summary>
        private void InitTime()
        {
            List<int> years = new List<int>();
            List<int> months = new List<int>();
            List<int> days = new List<int>();
            var now = DateTime.Now;

            try
            {
                for (int i = DateTime.Now.Year - 5; i < DateTime.Now.Year + 5; i++)
                    years.Add(i);
                for (int i = 1; i <= 12; i++)
                    months.Add(i);

                var total = DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month);

                for (int i = 1; i <= total; i++)
                    days.Add(i);

                this.viewModel.Whatyear = years;
                this.viewModel.Whatmonth = months;
                this.viewModel.Whatday = days;

                this.viewModel.Selectyear = now.Year;
                this.viewModel.Selectmonth = now.Month;
                this.viewModel.Selectday = now.Day;
            }
            catch (Exception)
            { 
            
            }
        }

        /// <summary>
        /// 월이 선택되면 해당 월에 마지막일자 계산
        /// </summary>
        private void RefreshDay()
        {
            List<int> days = new List<int>();
            var now = DateTime.Now;

            try
            {
                //년 월이 선택 되어있을떄만 작동하게 예외처리
                if (this.viewModel.Selectyear != null && this.viewModel.Selectmonth != null)
                {
                    var total = DateTime.DaysInMonth(this.viewModel.Selectyear.Value, this.viewModel.Selectmonth.Value);

                    for (int i = 1; i <= total; i++)
                        days.Add(i);
                }
            }
            catch (Exception)
            { 
            
            }
            finally
            {
                this.viewModel.Whatday = days;
            }
        }

        /// <summary>
        /// 이미지 등록 버튼 클릭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPhoto_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //오픈파일다이얼로그로 파일 선택하기 위해 선언
                OpenFileDialog openFileDialog = new OpenFileDialog();
                
                //선택이 되면
                if (openFileDialog.ShowDialog() == true)
                {
                    //파일 경로 입력
                    this.txt_PhotoPath.Text = openFileDialog.FileName;
                }
            }
            catch(Exception)
            {

            }
        }

        private void cmb_Year_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }

        private void cmb_Month_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //페이지가 로드 됬을떄만 작동하게 예외처리
            if (this.IsLoaded)
                this.RefreshDay();
        }

        /// <summary>
        /// 등록버튼 클릭 이벤트
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRegister_Complete_Click(object sender, RoutedEventArgs e)
        {
            bool? plasticBag = null;

            try
            {
                if (this.toilet_bag_yes.IsChecked.Value)
                    plasticBag = true;
                else if (this.toilet_bag_no.IsChecked.Value)
                    plasticBag = false;


                //데이터 유효성 체크
                if (plasticBag == null)
                    MessageBox.Show("배변봉투 여부를 선택하세요.");
                else if (!this.viewModel.Selectyear.HasValue ||
                    !this.viewModel.Selectmonth.HasValue ||
                    !this.viewModel.Selectday.HasValue)
                    MessageBox.Show("날짜를 선택해주세요.");
                else if (string.IsNullOrEmpty(this.viewModel.DogName))
                    MessageBox.Show("이름을 입력해주세요.");

                //유효성 체크
                using (var conn = new MySqlConnection(Common.ConnectionString))
                {
                    conn.Open();

                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = $@"INSERT INTO BOARD (imagefile, id, date_published, date, age, breed, nameofdog, plasticbag) values 
                                                    (@imagefile, @id, @date_published, @date, @age, @breed, @nameofdog, @plasticbag)";

                        if (File.Exists(this.txt_PhotoPath.Text))
                        {
                            byte[] binary = File.ReadAllBytes(this.txt_PhotoPath.Text);
                            cmd.Parameters.Add(new MySqlParameter("imagefile", binary));
                        }
                        else
                            cmd.Parameters.Add(new MySqlParameter("imagefile", null));

                        cmd.Parameters.Add(new MySqlParameter("id", "test"));
                        cmd.Parameters.Add(new MySqlParameter("post", this.viewModel.Post));
                        cmd.Parameters.Add(new MySqlParameter("date_published", DateTime.Now));
                        cmd.Parameters.Add(new MySqlParameter("date", new DateTime(this.viewModel.Selectyear.Value, this.viewModel.Selectmonth.Value, this.viewModel.Selectday.Value)));
                        cmd.Parameters.Add(new MySqlParameter("age", this.viewModel.DogAge));
                        cmd.Parameters.Add(new MySqlParameter("breed", this.viewModel.Breed));
                        cmd.Parameters.Add(new MySqlParameter("nameofdog", this.viewModel.DogName));
                        cmd.Parameters.Add(new MySqlParameter("plasticbag", Convert.ToInt32(plasticBag)));

                        cmd.ExecuteNonQuery();

                        MessageBox.Show("등록되었습니다.");
                    }

                    conn.Close();
                }

                //등록이되면 이전화면으로 이동
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {

            }
        }
    }
}
